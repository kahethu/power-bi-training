GDP data is fetched from https://en.wikipedia.org/wiki/List_of_countries_by_GDP_(PPP)_per_capita)

US census data is fetched from https://en.wikipedia.org/wiki/List_of_U.S._states_and_territories_by_historical_population
From the table "1790–1860, census data"